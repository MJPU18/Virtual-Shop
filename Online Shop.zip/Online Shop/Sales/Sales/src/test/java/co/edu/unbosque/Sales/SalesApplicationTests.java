package co.edu.unbosque.Sales;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesApplicationTests {

	@Test
	void contextLoads() {
	}

}
