package co.edu.unbosque;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalesDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalesDetailsApplication.class, args);
	}

}
